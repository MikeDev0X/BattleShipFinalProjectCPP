#include <iostream>
#include "Juego.h"

//Marco Antonio Gardida Cortés A01423221
//Miguel Jiménez Padilla A01423189
//Silvio Emmanuel Prieto Caro A01423341

int main() {
	Juego miJuego;
  miJuego.inicio();
}
//gatito
//gatito
//|\_/|
//(°^°)
